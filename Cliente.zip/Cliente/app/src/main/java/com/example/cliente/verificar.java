package com.example.cliente;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class verificar extends AppCompatActivity {
    Dialog myDialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_verificar);
        myDialog = new Dialog(this);
    }
    public void ShowDialog(View v){
        Button btnAceptar,btnCancelar;
        myDialog.setContentView(R.layout.pass);
        btnAceptar = (Button) myDialog.findViewById(R.id.btnAcep);
        btnCancelar = (Button) myDialog.findViewById(R.id.bntCancel);
        btnAceptar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                iraMenu(v);
            }
        });
        btnCancelar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myDialog.dismiss();
            }
        });
        myDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        myDialog.show();
    }

    public void iraMenu (View View){
        Intent i = new Intent(this, menuinicio.class);
        startActivity(i);
    }
}